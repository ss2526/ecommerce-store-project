module.exports = {
  mongoURI:
    "mongodb+srv://ajay:ajay@cluster0-fhjlv.mongodb.net/ecommerce-shop?retryWrites=true&w=majority",
  secretOrKey: "secret_key",
};
