export const CAT_NAMES = ["mens", "womens", "sneakers", "jackets", "hats"];
