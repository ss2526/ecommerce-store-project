import React from "react";
import Directory from "../../components/directory/directory.component";
export default function HomePage() {
  return (
    <React.Fragment>
      <Directory />
    </React.Fragment>
  );
}
