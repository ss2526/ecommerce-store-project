export const productActionTypes = {
  GET_PRODUCT: "GET_PRODUCT",
};
